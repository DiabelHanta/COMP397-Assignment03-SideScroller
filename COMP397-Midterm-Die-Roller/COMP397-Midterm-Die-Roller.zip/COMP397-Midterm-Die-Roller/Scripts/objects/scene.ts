﻿module objects {
    // DECLARE the SCENE CLASS
    export class Scene extends createjs.Container {
        // CONSTRUCTOR
        constructor() {
            super();
        }


        // PUBLIC METHODS
        public start(): void {
        }

        public update():void {
        }


    }
}