﻿module states
{
    // GAME CLASS
    export class Game extends objects.Scene
    {
        // PRIVATE INSTANCE VARIABLES
        private _levelLabel: objects.Label;
        private _backButton: objects.Button;
        private _nextButton: objects.Button;
        private _rollDice: objects.Button;
        private _die1: objects.Button;
        private _die2: objects.Button;
        private _die3: objects.Button;
        private _die4: objects.Button;
        private _die5: objects.Button;
        private _die6: objects.Button;

        // CONSTRUCTOR
        constructor()
        {
            super();
        }

        // PUBLIC METHODS
        public start(): void
        {

            // level label
            this._levelLabel = new objects.Label("Game Play", "60px Consolas", "#000000", 320, 240);
            this.addChild(this._levelLabel); // add label to the stage

            // back button
            this._backButton = new objects.Button("BackButton", 220, 340);
            this._backButton.on("click", this._clickBackButton, this); // event listener
            this.addChild(this._backButton);

            // next button
            this._nextButton = new objects.Button("NextButton", 420, 340);
            this._nextButton.on("click", this._clickNextButton, this); // event listener
            this.addChild(this._nextButton);

            // roll button
            this._rollDice = new objects.Button("roll", 420, 340);
            this._rollDice.on("click", this._clickRollDice, this); // event listener
            this.addChild(this._rollDice);

            stage.addChild(this);
        }

        public update(): void
        {
        }

        // PRIVATE METHODS ++++++++++++++++++++++++++++++++++++++++++++++
        // Callback function / Event Handler for Back Button Click
        private _clickBackButton(event: createjs.MouseEvent): void
        {
            changeState(config.MENU_STATE);
        }

        // Callback function / Event Handler for Next Button Click
        private _clickNextButton(event: createjs.MouseEvent): void
        {
            changeState(config.OVER_STATE);
        }

        // Callback function / Event Handler for roll Button Click
        private _clickRollDice(event: createjs.MouseEvent): void
        {
            changeState(config.OVER_STATE);
        }
    }
}